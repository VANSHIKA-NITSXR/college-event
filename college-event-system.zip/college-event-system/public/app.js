const $ = s => document.querySelector(s), app = $('#app'), modal = $('#modal');
const CATS = ['Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Club Activity', 'Other'];
let me = null, events = [], tab = 'browse', filter = { q: '', cat: '' };

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = d => new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
const formData = f => Object.fromEntries(new FormData(f));
async function api(url, method = 'GET', body) {
  const r = await fetch('/api/' + url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}
function toast(msg, err) { const t = $('#toast'); t.textContent = msg; t.className = 'show' + (err ? ' err' : ''); setTimeout(() => t.className = '', 2800); }
const run = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

async function init() { me = (await api('me')).user; if (me) await load(); render(); }
async function load() { events = await api('events'); }

function render() {
  if (!me) return authView();
  const org = me.role === 'organizer';
  app.innerHTML = `<header><h1>Campus Events</h1>
    <nav>${org ? tabBtn('manage', 'My events') : tabBtn('browse', 'Browse events') + tabBtn('mine', 'My registrations')}</nav>
    <span>${esc(me.name)} (${me.role})</span><button class="btn alt sm" id="out" style="color:#fff">Log out</button></header><main id="main"></main>`;
  if (org && tab !== 'manage') tab = 'manage'; if (!org && tab === 'manage') tab = 'browse';
  document.querySelectorAll('nav button').forEach(b => b.onclick = () => { tab = b.dataset.t; render(); });
  $('#out').onclick = run(async () => { await api('logout', 'POST'); me = null; render(); });
  if (tab === 'manage') manageView(); else if (tab === 'mine') mineView(); else browseView();
}
const tabBtn = (t, l) => `<button data-t="${t}" class="${tab === t ? 'on' : ''}">${l}</button>`;

function authView(signup = false) {
  app.innerHTML = `<form class="card" id="f"><h2>${signup ? 'Create account' : 'Log in'}</h2>
    ${signup ? `<label>Full name</label><input name="name" required>` : ''}
    <label>College email</label><input name="email" type="email" required>
    <label>Password</label><input name="password" type="password" minlength="6" required>
    ${signup ? `<label>I am a</label><select name="role"><option value="participant">Participant (student)</option><option value="organizer">Organizer</option></select>
    <div id="codeBox" hidden><label>Organizer access code</label><input name="code"></div>` : ''}
    <p><button class="btn">${signup ? 'Sign up' : 'Log in'}</button>
    <button type="button" class="btn alt" id="sw">${signup ? 'I have an account' : 'Create an account'}</button></p></form>`;
  $('#sw').onclick = () => authView(!signup);
  if (signup) $('[name=role]').onchange = e => $('#codeBox').hidden = e.target.value !== 'organizer';
  $('#f').onsubmit = run(async e => {
    e.preventDefault(); me = (await api(signup ? 'signup' : 'login', 'POST', formData(e.target))).user;
    tab = me.role === 'organizer' ? 'manage' : 'browse'; await load(); render();
  });
}

function ticket(e, actions) {
  const d = new Date(e.date), past = d < new Date(), left = e.capacity - e.count, closed = new Date() > new Date(e.deadline);
  return `<article class="ticket"><div class="stub ${past ? 'past' : ''}"><b>${d.getDate()}</b>${d.toLocaleString([], { month: 'short' })} ${d.getFullYear()}</div>
  <div class="info"><span class="tag">${esc(e.category)}</span>${past ? '<span class="tag red">Ended</span>' : closed ? '<span class="tag red">Registration closed</span>' : left <= 0 ? '<span class="tag red">Full</span>' : ''}
  <h3>${esc(e.title)}</h3><div class="meta">${fmt(e.date)} at ${esc(e.venue)}<br>${e.count}/${e.capacity} registered. Register by ${fmt(e.deadline)}.
  Organizer: ${esc(e.organizerName)}${e.contact ? ', contact ' + esc(e.contact) : ''}</div>
  <p>${esc(e.description)}</p><div class="acts">${actions}</div></div></article>`;
}

function browseView() {
  const list = events.filter(e => (!filter.cat || e.category === filter.cat) && (e.title + e.venue + e.description).toLowerCase().includes(filter.q.toLowerCase()));
  $('#main').innerHTML = `<div class="bar"><h2>Upcoming and past events</h2><span>
    <input id="q" placeholder="Search events" value="${esc(filter.q)}"> <select id="cat"><option value="">All categories</option>${CATS.map(c => `<option ${c === filter.cat ? 'selected' : ''}>${c}</option>`).join('')}</select></span></div>
    ${list.map(e => ticket(e, e.registered ? `<button class="btn alt sm" data-cancel="${e.id}">Cancel registration</button><span class="meta">You are registered.</span>` : `<button class="btn sm" data-reg="${e.id}">Register</button>`)).join('') || '<p class="empty">No events match. Try a different search.</p>'}`;
  $('#q').oninput = e => { filter.q = e.target.value; browseView(); $('#q').focus(); $('#q').setSelectionRange(99, 99); };
  $('#cat').onchange = e => { filter.cat = e.target.value; browseView(); };
  document.querySelectorAll('[data-reg]').forEach(b => b.onclick = () => regForm(b.dataset.reg));
  document.querySelectorAll('[data-cancel]').forEach(b => b.onclick = run(async () => {
    if (!confirm('Cancel your registration?')) return; await api(`events/${b.dataset.cancel}/register`, 'DELETE'); await load(); render(); toast('Registration cancelled');
  }));
}

function regForm(id) {
  const e = events.find(x => x.id === id);
  modal.innerHTML = `<form id="rf"><h2>Register for ${esc(e.title)}</h2><p class="meta">Registering as ${esc(me.name)} (${esc(me.email)})</p>
    <div class="row"><div><label>Roll number</label><input name="rollNo" required></div><div><label>Phone</label><input name="phone" type="tel" required></div></div>
    <div class="row"><div><label>Department</label><input name="department" required></div>
    <div><label>Year of study</label><select name="year"><option>1st</option><option>2nd</option><option>3rd</option><option>4th</option><option>PG</option></select></div></div>
    <p><button class="btn">Confirm registration</button> <button type="button" class="btn alt" data-close>Close</button></p></form>`;
  modal.showModal();
  $('#rf').onsubmit = run(async ev => { ev.preventDefault(); await api(`events/${id}/register`, 'POST', formData(ev.target)); modal.close(); await load(); render(); toast('Registered'); });
}

async function mineView() {
  const regs = await api('mine');
  $('#main').innerHTML = `<h2>My registrations</h2>${regs.map(r => ticket({ ...r.event, count: events.find(e => e.id === r.eventId)?.count ?? 0, organizerName: events.find(e => e.id === r.eventId)?.organizerName },
    `<span class="meta">Roll no. ${esc(r.rollNo)}, ${esc(r.department)}, ${esc(r.year)} year. ${r.attended ? 'Attendance marked.' : ''}</span>`)).join('') || '<p class="empty">You have not registered for any event yet. Open Browse events to find one.</p>'}`;
}

function manageView() {
  const mine = events.filter(e => e.organizerId === me.id);
  $('#main').innerHTML = `<div class="bar"><h2>My events</h2><button class="btn" id="new">Create event</button></div>
    ${mine.map(e => ticket(e, `<button class="btn sm" data-regs="${e.id}">Participants</button><button class="btn alt sm" data-edit="${e.id}">Edit</button><button class="btn danger sm" data-del="${e.id}">Delete</button>`)).join('') || '<p class="empty">You have not created any events yet. Select Create event to add the first one.</p>'}`;
  $('#new').onclick = () => eventForm();
  document.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => eventForm(events.find(e => e.id === b.dataset.edit)));
  document.querySelectorAll('[data-regs]').forEach(b => b.onclick = run(() => regsDialog(b.dataset.regs)));
  document.querySelectorAll('[data-del]').forEach(b => b.onclick = run(async () => {
    if (!confirm('Delete this event and all its registrations?')) return; await api('events/' + b.dataset.del, 'DELETE'); await load(); render(); toast('Event deleted');
  }));
}

function eventForm(e = {}) {
  const v = k => esc(e[k] ?? '');
  modal.innerHTML = `<form id="ef"><h2>${e.id ? 'Edit event' : 'Create event'}</h2>
    <label>Title</label><input name="title" value="${v('title')}" required>
    <label>Description</label><textarea name="description" rows="3">${v('description')}</textarea>
    <div class="row"><div><label>Category</label><select name="category">${CATS.map(c => `<option ${c === e.category ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
    <div><label>Venue</label><input name="venue" value="${v('venue')}" required></div></div>
    <div class="row"><div><label>Date and time</label><input type="datetime-local" name="date" value="${v('date')}" required></div>
    <div><label>Registration deadline</label><input type="datetime-local" name="deadline" value="${v('deadline')}" required></div></div>
    <div class="row"><div><label>Maximum participants</label><input type="number" min="1" name="capacity" value="${v('capacity')}" required></div>
    <div><label>Contact (phone or email)</label><input name="contact" value="${v('contact')}"></div></div>
    <p><button class="btn">${e.id ? 'Save changes' : 'Create event'}</button> <button type="button" class="btn alt" data-close>Close</button></p></form>`;
  modal.showModal();
  $('#ef').onsubmit = run(async ev => { ev.preventDefault(); await api(e.id ? 'events/' + e.id : 'events', e.id ? 'PUT' : 'POST', formData(ev.target)); modal.close(); await load(); render(); toast(e.id ? 'Changes saved' : 'Event created'); });
}

async function regsDialog(id) {
  const e = events.find(x => x.id === id), regs = await api(`events/${id}/registrations`);
  modal.innerHTML = `<h2>${esc(e.title)}: participants (${regs.length}/${e.capacity})</h2>
    ${regs.length ? `<div class="scroll"><table><tr><th>Name</th><th>Email</th><th>Roll no.</th><th>Dept.</th><th>Year</th><th>Phone</th><th>Present</th><th></th></tr>
    ${regs.map(r => `<tr><td>${esc(r.name)}</td><td>${esc(r.email)}</td><td>${esc(r.rollNo)}</td><td>${esc(r.department)}</td><td>${esc(r.year)}</td><td>${esc(r.phone)}</td>
    <td><input type="checkbox" data-att="${r.id}" ${r.attended ? 'checked' : ''} aria-label="Present"></td><td><button class="btn danger sm" data-rm="${r.id}">Remove</button></td></tr>`).join('')}</table></div>` : '<p class="empty">No one has registered yet.</p>'}
    <p><a class="btn" href="/api/events/${id}/export">Download CSV</a> <button class="btn alt" data-close>Close</button></p>`;
  modal.showModal();
  modal.querySelectorAll('[data-att]').forEach(c => c.onchange = run(() => api('regs/' + c.dataset.att, 'PATCH', { attended: c.checked })));
  modal.querySelectorAll('[data-rm]').forEach(b => b.onclick = run(async () => {
    if (!confirm('Remove this participant?')) return; await api('regs/' + b.dataset.rm, 'DELETE'); await load(); await regsDialog(id); manageView();
  }));
}
modal.addEventListener('click', e => { if (e.target.hasAttribute('data-close') || e.target === modal) modal.close(); });
init();
